# compleat plugin

This plugin looks for [compleat](https://github.com/mbrubeck/compleat) and loads its completion.

To use it, add compleat to the plugins array in your zshrc file:

```zsh
plugins=(... compleat)
```
